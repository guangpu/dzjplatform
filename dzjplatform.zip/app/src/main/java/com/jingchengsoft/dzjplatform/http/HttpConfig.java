package com.jingchengsoft.dzjplatform.http;

/**
 * @author xxh
 * @date 2019/11/11
 * @desc TODO.
 */
public class HttpConfig {
    public static final int PAGE_SIZE = 20;

    public static final String BASE_URL = "http://192.168.31.45:9010/";
    public static final String LOGIN = "apia/v1/user/login";
}

