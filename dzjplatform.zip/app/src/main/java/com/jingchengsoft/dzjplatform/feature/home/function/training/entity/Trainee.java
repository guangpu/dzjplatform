package com.jingchengsoft.dzjplatform.feature.home.function.training.entity;

/**
 * author : wgp
 * time   :  2020/3/16
 * desc   :  培训人员
 */
public class Trainee {

    /**
     * address :
     * education : 3
     * score2 : 0
     * score3 : 0
     * score4 : 0
     * sex : 1
     * birth_date : 1990/01/30
     * id_card : 371481199004117255
     * comp_id :
     * special_card :
     * job_site :
     * name : 张杰
     * id : 1fe101bce6c24990b69b883ceca58051
     * score1 : 10
     */

    private String address;
    private String education;
    private int score2;
    private int score3;
    private int score4;
    private String sex;
    private String birth_date;
    private String id_card;
    private String comp_id;
    private String special_card;
    private String job_site;
    private String name;
    private String id;
    private int score1;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public int getScore2() {
        return score2;
    }

    public void setScore2(int score2) {
        this.score2 = score2;
    }

    public int getScore3() {
        return score3;
    }

    public void setScore3(int score3) {
        this.score3 = score3;
    }

    public int getScore4() {
        return score4;
    }

    public void setScore4(int score4) {
        this.score4 = score4;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(String birth_date) {
        this.birth_date = birth_date;
    }

    public String getId_card() {
        return id_card;
    }

    public void setId_card(String id_card) {
        this.id_card = id_card;
    }

    public String getComp_id() {
        return comp_id;
    }

    public void setComp_id(String comp_id) {
        this.comp_id = comp_id;
    }

    public String getSpecial_card() {
        return special_card;
    }

    public void setSpecial_card(String special_card) {
        this.special_card = special_card;
    }

    public String getJob_site() {
        return job_site;
    }

    public void setJob_site(String job_site) {
        this.job_site = job_site;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getScore1() {
        return score1;
    }

    public void setScore1(int score1) {
        this.score1 = score1;
    }
}
