package com.jingchengsoft.dzjplatform.feature.home.function.statistic.fragment;

import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.jingchengsoft.dzjplatform.R;
import com.jingchengsoft.dzjplatform.common.MyFragment;
import com.jingchengsoft.dzjplatform.feature.home.function.statistic.activity.StatisticActivity;
import com.jingchengsoft.dzjplatform.feature.home.function.statistic.chart.EchartView;
import com.jingchengsoft.dzjplatform.feature.home.function.statistic.utils.RiskEchartOptionUtil;
import com.jingchengsoft.dzjplatform.feature.home.web.BrowserActivity;
import com.jingchengsoft.dzjplatform.ui.widget.BrowserView;

import butterknife.BindView;

/**
 * author : wgp
 * time   :  2020/4/1
 * desc   :
 */
public class RiskStatisticFragment extends MyFragment<StatisticActivity> {

    public static RiskStatisticFragment newInstance() {
        return new RiskStatisticFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_risk_statistic;
    }

    @BindView(R.id.lineChart)
    EchartView lineChart;

    @Override
    protected void initView() {
        lineChart.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                //最好在h5页面加载完毕后再加载数据，防止html的标签还未加载完成，不能正常显示
                refreshLineChart();
            }
        });
    }

    @Override
    protected void initData() {

    }

    private void refreshLineChart(){
        Object[] x = new Object[]{
                "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"
        };
        Object[] y = new Object[]{
                820, 932, 901, 934, 1290, 1330, 1320
        };
        lineChart.refreshEchartsWithOption(RiskEchartOptionUtil.getLineAndBarChartOption());
    }
}
