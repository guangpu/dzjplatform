package com.jingchengsoft.ykplatform.common.copy.kotlin


import com.jingchengsoft.dzjplatform.R
import com.jingchengsoft.dzjplatform.common.MyActivity

/**
 * @author MaybeSix
 * @date 2019/11/6
 * @desc TODO.
 */
class CopyActivity : MyActivity() {

    override fun getLayoutId(): Int {
        return R.layout.activity_copy
    }

    override fun initView() {

    }

    override fun initData() {

    }
}